package ids;

import java.io.IOException;

import jpcap.*;
import jpcap.packet.Packet;

import jpcap.PacketReceiver;
/*import jp.ac.kobe_u.cs.prolog.lang.*;*/




class Sniffer implements PacketReceiver{
	
	private Blackboard blackboard;
	

	public void start() {
		
		try{
		
		JpcapCaptor jpcap=JpcapCaptor.openDevice(JpcapCaptor.getDeviceList()[1],1000,false,20);
		jpcap.setFilter("tcp", true);
		//jpcap.processPacket(1000,this);
		jpcap.loopPacket(100, this);
		}
		catch (java.io.IOException e) {
			System.out.println("I/O Exception");
		}
				
		
		
	}
	
public void readFile(String file){
	
	try {
		
		JpcapCaptor jpcap = JpcapCaptor.openFile(file);
		jpcap.processPacket(-1, this);
		System.out.println("pacchetti ricevuti" + jpcap.received_packets);
		
		int n = jpcap.received_packets;
		
		while(n > 0){
			blackboard.write(jpcap.getPacket());
			n--;
			
		}
				
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	
	
	
public void receivePacket(Packet packet) {
	
	System.out.println("scrivo pacchetto blackboard");
	blackboard.write(packet);
	
	

}


public Blackboard getBlackboard() {
	return blackboard;
}

public void setBlackboard(Blackboard blackboard) {
	this.blackboard = blackboard;
}


}
