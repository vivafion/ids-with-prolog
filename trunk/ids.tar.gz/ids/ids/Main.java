package ids;

import jpcap.NetworkInterface;
import jpl.Atom;
import jpl.JPL;
import jpl.Query;
import jpl.Term;


public class Main {

	public static void init(){
		
		JPL.init();

		Term consult_arg[] = { 
				new Atom( "kb.pl" ) 
			};
			Query consult_query = 
				new Query( 
					"consult", 
					consult_arg );

			
			boolean consulted = consult_query.query();
			
			if ( !consulted ){
				System.err.println( "Consult failed" );
				System.exit( 1 );
			}
			NetworkInterface[] lists=jpcap.JpcapCaptor.getDeviceList();


	
		
	}
	
	
	public static void main(String[] args) {

		Blackboard blackBoard = new Blackboard();
		
		Analyzer analyzer = new Analyzer();
		
		Sniffer sniffer = new Sniffer();
		
		init();
		
		analyzer.setBlackboard(blackBoard);
		
		sniffer.setBlackboard(blackBoard);
		
		
		System.out.println("avvio sniffer");
		//sniffer.start();
		
		sniffer.readFile("/home/p1mps/ids-with-prolog/ids/scan_nmap.pcap");
		
		System.out.println("avvio analyzer");
		analyzer.run();
		
		
	}

}
