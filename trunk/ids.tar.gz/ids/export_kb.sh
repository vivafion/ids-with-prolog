#!/bin/sb

java -cp plcafe.jar     jp.ac.kobe_u.cs.prolog.compiler.Compiler kb.pl;
javac -d . -cp plcafe.jar *PRED*
jar cf kb.jar *.class



